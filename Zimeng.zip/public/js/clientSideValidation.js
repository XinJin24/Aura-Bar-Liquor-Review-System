//front side validation for
// 1. login,
// 2. register,
// 3. modifying user info(accessible to user and admin),
// 4. modifying drink info(only available to admin)
// 5. searching bar(drinks homepage)